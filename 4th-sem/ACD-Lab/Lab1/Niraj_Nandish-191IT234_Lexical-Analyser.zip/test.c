#include <stdio.h>
#define xyz +

int main()
{
    char i = 'a', c;
    int f = 0;
    scanf("%c", &c);
    printf("%c", c);
    /* This is a multiline 
    comment **********.
    */
    56abcd = 89;
    printf("The result is %d", f);
}
// single line comment