{
    asda = adsfdf + asd;
    for (i = 10; i < 1; i++)
    {
    }
    if (i <= 10){
	} else 
        i = 200;
    }
    asd -s ;
    2 - 3;
}