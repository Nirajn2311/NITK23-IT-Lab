#include <iostream>
#include <list>

// Enter the Edges with Vertice Numbers starting from 1 and not 0 i.e. First Edge is 1 and not 0

using namespace std;

class Graph
{
    int numVertices;
    list<int> *adjLists;
    bool *visited;

public:
    Graph(int vertices);
    void addEdge(int src, int dest);
    void BFS(int startVertex, int &Contact);
};

Graph::Graph(int vertices)
{
    numVertices = vertices;
    adjLists = new list<int>[vertices];
}

void Graph::addEdge(int src, int dest)
{
    adjLists[src].push_back(dest);
    adjLists[dest].push_back(src);
}

void Graph::BFS(int startVertex, int &Contact)
{
    visited = new bool[numVertices];
    for (int i = 0; i < numVertices; i++)
        visited[i] = false;

    list<int> queue;

    visited[startVertex] = true;
    queue.push_back(startVertex);

    list<int>::iterator i;

    while (!queue.empty())
    {
        int currVertex = queue.front();
        Contact++;
        queue.pop_front();

        for (i = adjLists[currVertex].begin(); i != adjLists[currVertex].end(); ++i)
        {
            int adjVertex = *i;
            if (!visited[adjVertex])
            {
                visited[adjVertex] = true;
                queue.push_back(adjVertex);
            }
        }
    }
}

int main()
{
    int ver, edg, con = 1;
    cout << "Enter the Number of Vertices : ";
    cin >> ver;
    cout << "Enter the Number of Edges : ";
    cin >> edg;

    auto edges = new int[edg][2];
    for (int i = 0; i < edg; i++)
    {
        int x, y;
        cin >> x >> y;
        edges[i][0] = x - 1;
        edges[i][1] = y - 1;
    }

    for (int i = 0; i < edg; i++)
    {
        int Contact = 0;
        Graph G(ver);
        for (int j = 0; j < edg; j++)
        {
            if (j == i)
                continue;
            else
            {
                int a = edges[j][0], b = edges[j][1];
                G.addEdge(a, b);
            }
        }
        G.BFS(0, Contact);
        if (Contact != ver)
        {
            con = 0;
            cout << "\nThe Bridge Edge is : " << edges[i][0] + 1 << " " << edges[i][1] + 1;
        }
    }

    if (con == 0)
    {
        cout << "\nIt is not a 2 - Edge connected Graph";
    }
    else
    {
        cout << "The Graph is 2-edge connected";
    }
}