#include <iostream>
#include <string>
#include <stdlib.h>
#include <math.h>
#include <ctime>
#include <chrono>
#include <ratio>

#define max 100000

using namespace std;

int hashfunction(string x)
{
    int sum = 0, len = x.size();
    for (int i = 0; i < len; i++)
    {
        sum += (int(x[i]) * pow(3, i + 1));
    }
    return sum;
}

struct node
{
    string data;
} Hash[max];

void insert_data(string x, int loc)
{
    int inserted = 0;

    for (int i = 0; inserted == 0; i++)
    {
        if (Hash[loc + i].data.empty())
        {
            Hash[loc + i].data = x;
            inserted = 1;
        }
        if (loc + i == max)
        {
            loc = 0;
            i = 0;
        }
    }
}

void delete_data(int loc)
{
    if (Hash[loc].data.empty())
    {

        return;
    }
    Hash[loc].data.clear();
}

void search_data(string x, int loc)
{
    int found = 0;
    for (int i = 0; found == 0; i++)
    {
        if (Hash[loc + i].data.compare(x) == 0)
        {
            found = 1;
            return;
        }
        if (loc + i == max)
        {
            loc = 0;
            i = 0;
        }
        if (Hash[loc + i].data.empty())
        {
            return;
        }
    }
}

int main()
{
    int inserted = 0;
    float load;

    do
    {
        srand((unsigned)time(0));
        for (int i = 0; i < 7; i++, inserted++)
        {
            int x = abs(rand() * 999999 / RAND_MAX);
            int loc = hashfunction(to_string(x));
            if (loc > max)
                loc = loc - max;
            insert_data(to_string(x), loc);
        }

        for (int i = 0; i < 2; i++, inserted--)
        {

            int x = abs(rand() * 999999 / RAND_MAX);
            int loc = hashfunction(to_string(x));
            if (loc > max)
                loc = loc - max;
            delete_data(loc);
        }

        for (int i = 0; i < 1; i++)
        {
            chrono::high_resolution_clock::time_point t1 = chrono::high_resolution_clock::now();
            srand((unsigned)time(0));
            int x = abs(rand() * 999999 / RAND_MAX);
            int loc = hashfunction(to_string(x));
            if (loc > max)
                loc = loc - max;
            search_data(to_string(x), loc);
            chrono::high_resolution_clock::time_point t2 = chrono::high_resolution_clock::now();
            chrono::duration<double, std::milli> searchtime = t2 - t1;
            if (searchtime.count() > 0)
                cout << inserted << "\t" << float(searchtime.count()) << endl;
        }

    } while (inserted <= 80000);

    return 0;
}