// BST Assignment q2
#include<iostream>
#include<bits/stdc++.h>
using namespace std;

struct node
{
  int data;
  node* right;
  node* left;
};

class BinarySearchTree
{
  node* root;
  public:
      BinarySearchTree()
      {
        root=NULL;
      }

      void insert(int data1)
      {
        node*p=new node;
        p->data=data1;
        p->right=NULL;
        p->left=NULL;
        if(root==NULL)
        {
          root=p;
        }
        else
        {
          node* x=root;
          node* y=root;
          while(x!=NULL)
          {
            y=x;
            if(data1<x->data)
            {
              x=x->left;
            }
            else
            if(data1>x->data)
            {
              x=x->right;
            }
          }
          if(data1>y->data)
          {
            y->right=p;
          }
          else
          if(data1<y->data)
          {
            y->left=p;
          }
        }
      }

      int search(int data1)
      {
        if(root==NULL)
        {
          cout<<"The BST is empty!!"<<endl;
          return 0;
        }
        else
        {
          int count=0;
          int found=0;
          node* x=root;
          while(x!=NULL&&found==0)
          {
            if(data1<x->data)
            {
              x=x->left;
              count++;
            }
            else
            if(data1>x->data)
            {
              x=x->right;
              count++;
            }
            else
            if(data1==x->data)
            {
              found=1;
              count++;
            }
          }
        return count;
      }
    }
};

int main()
{
  BinarySearchTree obj;
  int insert[10000];
  int random;
  int sum=0;
  for(int i=0;i<10000;i++)
  {
    random=rand();
    insert[i]=random;
    obj.insert(insert[i]);
  } 
  for(int i=0;i<1000;i++)
  {
    int y=obj.search(insert[i]);
    sum+=y;
  }
  float result=float(sum)/1000;
  cout<<result<<endl;
  return 0;
}