#include<bits/stdc++.h>
#include<iostream>
using namespace std;

struct node
{
  char data;
  node* right;
  node* left;
};
 
class BinaryTree
{
  public:
    node* create(vector<char> &inorder,vector<char>& preorder)
    {
       return createmain(0,inorder.size()-1,0,inorder,preorder);
    }

    node* createmain(int inbeg,int inend,int prebeg,vector<char> &inorder,vector<char>& preorder)
    {
      if(inbeg>inend)
      {
        return NULL;
      }
      node* x=new node;
      x->data=preorder[prebeg];
      x->right=NULL;
      x->left=NULL;
      int index=0;
      for(int i=inbeg;i<=inend;i++)
      {
        if(inorder[i]==x->data)
        {
          index=i;
        }
      }
      x->left=createmain(inbeg,index-1,prebeg+1,inorder,preorder);
      x->right=createmain(index+1,inend,index-inbeg+prebeg+1,inorder,preorder);
      return x;
    }
    void display(node* root)
    {
      if(root==NULL)
      {
        return;
      }
      cout<<root->data<<" ";
      display(root->left);
      display(root->right);
    }
};

int main()
{
  BinaryTree obj;
  vector<char>inorder={'D','B','A','G','E','H','C','F'};
  vector<char>preorder={'A','B','D','C','E','G','H','F'};
  node* root=obj.create(inorder,preorder);
  cout<<endl;
  cout<<"BINARY TREE IN PREORDER "<<endl;
  cout<<endl;
  obj.display(root);
  cout<<endl;
  return 0;
}